<!DOCTYPE html>
<html> 
<head>
<title> E&T's Hospital | Registration </title>

		<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600&amp;subset=cyrillic,latin">
		<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" href="assets/css/header.css">
		<link rel="stylesheet" href="assets/css/footer.css">
		<link rel="stylesheet" href="assets/plugins/line-icons-pro/styles.css">
		<link rel="stylesheet" href="assets/plugins/line-icons/line-icons.css">
		<link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/custom.css">

</head>

<body>
		<div class="wrapper">
		<!--=== Header v1 ===-->
		<div class="header-v1">
		<!-- Topbar -->
		<div class="topbar-v1">
		<div class="container">
		<div class="row">
		<div class="col-md-6">
			<ul class="list-inline top-v1-contacts">
				<li>
					<i class="fa fa-envelope"></i> Email: e&thospital@gmail.com
				</li>
				<li>
					<i class="fa fa-phone"></i> Contact no : +92 333 00xxxxx
				</li>
			</ul>
		</div>
		</div>
		</div>
		</div>

<!-- End Topbar -->

			<!-- Navbar -->
			<div class="navbar mega-menu" role="navigation" style=" height: 17vh;">
				<div class="container">
					<div class="res-container">
						<button type="button" class="navbar-toggle" data-toggle="collapse"
							data-target=".navbar-responsive-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<div class="navbar-brand" style=">
							<a href="index.html">
								<img src="assets/img/logo/logo hos.png" alt="Logo" style="height: 14vh; width: 150px;">
							</a>
						</div>
					</div><!--/end responsive container-->

					<!-- nav links -->
					<div class="collapse navbar-collapse navbar-responsive-collapse">
						<div class="res-container">
							<ul class="nav navbar-nav">
								<!-- Home  -->
								<li class="mega-menu-fullwidth">
									<a href="index.html">
										<strong>HOME</strong>
									</a>

								</li>
								<!-- End Home-->

								<!-- About Us -->
								<li class="mega-menu-fullwidth">
									<a href="about.html">
										<strong>ABOUT US</strong>
									</a>
								</li>
								<!-- End About us -->

								<!-- Doctors -->
								<li class="mega-menu-fullwidth">
									<a href="doctors.html">
										<strong>DOCTORS</strong>
									</a>

								</li>
								<!-- End Doctors -->
						
								<!-- Contact Us -->
								<li class="mega-menu-fullwidth">
									<a href="contact.html">
										<strong>CONTACT US</strong>
									</a>
								</li>
								<!-- End Contact us -->

								<!-- Registration -->
								<li class="mega-menu-fullwidth">
									<a href="registration.php">
										<strong>REGISTRATION</strong>
									</a>
								</li>
								<!-- End registration -->

								<!-- login -->
								<li class="mega-menu-fullwidth">
									<a href="login.html">
										<strong>BOOK APPOINTMENT</strong>
									</a>
								</li>
								<!-- End login -->

								<!-- Appointment -->
								<!-- <li class="mega-menu-fullwidth">
									<a href="appointment.html">
										<strong>BOOK APPOINTMENT</strong>
									</a>

								</li> -->
								<!-- End Appointment -->

							</ul>

						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Navbar -->


	<!-- Image title -->

	<div style="text-align: center; margin-top: 50px;">
	<h2>REGISTER</h2>
	</div>

	<!-- End title  -->


				<!--=== Content Part ===-->
				<div class="container content">
				<div class="row">
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
				<!-- <form action="registr_backend.php" onsubmit="showMsg(0);return false;" method="post" class="reg-page"> -->
				<form action="registr_backend.php" method="post" >
				<div class="reg-header">
				<h2>Register a new account</h2>
				<p>Already Signed Up? Click <a href="login.html" class="color-green">Sign In</a> to login your account.</p>
				</div>

				<label for="first_name">First Name</label>
				<input type="text" id="first_name" name="first_name" class="form-control " style="margin-bottom: 20px;" required="">

				<label for="last_name">Last Name</label>
				<input type="text" id="last_name" name="last_name" class="form-control " style="margin-bottom: 20px;" required="">

				<label for="email">Email Address <span class="color-red">*</span></label>
				<input type="text" id="email" name="email" class="form-control " style="margin-bottom: 20px;" required="">

				<div class="row">
				<div class="col-sm-6">
				<label for="password">Password <span class="color-red">*</span></label>
				<input type="password" id="password" name="password" class="form-control " style="margin-bottom: 20px;" required="">
				</div>
				<div class="col-sm-6">
				<label for="cnfrm_password">Confirm Password <span class="color-red">*</span></label>
				<input type="password" id="cnfrm_password" name="cnfrm_password" class="form-control " style="margin-bottom: 20px;" required="">
				</div>
				</div>
				<div class="alert alert-success successBox">
				 <button type="button" class="close" onclick="showMsg(1);">×</button>
				 <strong style="font-size: 16px;">Congratulations!</strong><span class="alert-link"> You Have Successfully Registered.</span> 
				</div>

				<hr>

				<div class="row">
				<div class="col-lg-6 checkbox">
				<label>
				<input type="checkbox" required="">
				I read <a href="#" class="color-green">Terms and Conditions</a>
				</label>
				</div>
				<div class="col-lg-6 text-right">
				<input type="submit" value="Register" class="btn-u">
				<!-- <button class="btn-u" type="submit">Register</button> -->
				</div>
				</div>
				</form>
				</div>
				</div>
				</div><!--/container-->
				<!--=== End Content Part ===-->

		<!--=== Footer ===-->
		<div class="footer-v1">
			<div class="footer">
				<div class="container">
					<div class="row">
						<!-- About -->
						<div class="col-md-5 md-margin-bottom-40">
							<img id="logo-footer" class="footer-logo"
									src="assets/img/logo/logo_white.png" alt="" height="120vh"></a>
							<p>At E&T's Hospital, we are convinced that 'quality' and 'lowest cost' are not mutually
								exclusive when it comes to healthcare delivery.</p>
							<p>Our mission is to deliver high quality, affordable healthcare services to the peoples
								of Pakistan.</p>
						</div>

						<!-- Link List -->
						<div class="col-md-3" style="margin-bottom: 40px;">
							<div class="headline">
								<h2>Useful Links</h2>
							</div>
							<ul class="list-unstyled link-list">
								<li><a href="about.html">About us</a><i class="fa fa-angle-right"></i></li>
								<li><a href="Contact.html">Contact us</a><i class="fa fa-angle-right"></i></li>
								<li><a href="appointment.html">Book Appointment</a><i class="fa fa-angle-right"></i>
								</li>
							</ul>
						</div>
						<!-- End Link List -->

						<!-- Address -->
						<div class="col-md-3 map-img" style="margin-bottom: 40px;">
							<div class="headline">
								<h2>Contact Us</h2>
							</div>
							<address class="md-margin-bottom-40">
								E&T's Hospital <br />
								Hyderabad, <br />
								Phone: +92 333 00xxxxx <br />
								Email: e&thospital@gmail.com
							</address>
						</div>
						<!-- End Address -->
					</div>
				</div>
			</div><!--/footer-->

		<div class="copyright">
		<div class="container">
		<div class="row">
		<div class="col-md-6">
		<p>
		2020 &copy; All Rights Reserved.
		<a href="privacy.html">Privacy Policy</a> | <a href="terms.html">Terms of Service</a>
		</p>
		</div>

		<!-- Social Links -->
		<div class="col-md-6">
		<ul class="footer-socials list-inline">
		<li>
		<a href="http://www.facebook.com" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook">
		<i class="fa fa-facebook"></i>
		</a>
		</li>
		<li>
		<a href="http://www.skype.com" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Skype">
		<i class="fa fa-skype"></i>
		</a>
		</li>
		<li>
		<a href="http://www.googleplus.com" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google Plus">
		<i class="fa fa-google-plus"></i>
		</a>
		</li>
		<li>
		<a href="http://www.linkedin.com" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Linkedin">
		<i class="fa fa-linkedin"></i>
		</a>
		</li>
		<li>
		<a href="http://www.Pinterest.com" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Pinterest">
		<i class="fa fa-pinterest"></i>
		</a>
		</li>
		<li>
		<a href="http://www.twitter.com" class="tooltips" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter">
		<i class="fa fa-twitter"></i>
		</a>
		</li>
		</ul>
		</div>
		<!-- End Social Links -->
		</div>
		</div>
		</div><!--/copyright-->
		</div>
		<!--=== End Footer ===-->
</div><!--/wrapper-->

	<!-- Java scripts -->
	<script type="text/javascript" src="assets/plugins/jquery/jquery.min.js"></script>
	<script type="text/javascript">
	function showMsg(flag){
	if(flag==0){
	$('.successBox').css('display', 'block');
	}else{
	$('.successBox').css('display', 'none');
	}
	}
	</script>

</body>
</html>